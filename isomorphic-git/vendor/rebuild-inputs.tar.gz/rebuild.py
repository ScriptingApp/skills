import json, hashlib
from pathlib import Path
ROOT=Path(__file__).absolute().parent
reg=json.loads((ROOT/"rebuild-inputs/registry.json").read_text())
entry=reg["entry"];mappings=reg["maps"];mods={mid:(ROOT/"rebuild-inputs"/(mid+".js")).read_text() for mid in mappings}
parts=['/* isomorphic-git 1.38.1 Scripting batch extension; generated from readable CJS. */\n(function(root,factory){if(typeof module===\'object\'&&module.exports)module.exports=factory();else root.IsomorphicGit=factory();})(typeof globalThis!==\'undefined\'?globalThis:this,function(){\nvar nativeRequire=typeof require===\'function\'?require:null;var modules={'];
for mid,text in mods.items(): parts.append(json.dumps(mid)+':function(require,module,exports){\n'+text+'\n},')
parts.append('};var maps='+json.dumps(mappings)+';var cache={};function load(id){if(id.charAt(0)===\'@\'){var name=id.slice(1);if(name===\'buffer\')return {Buffer:Buffer};if(name===\'process\')return typeof process!==\'undefined\'?process:{};if(nativeRequire)return nativeRequire(name);throw new Error(\'Native module unavailable: \'+name);}if(cache[id])return cache[id].exports;var module={exports:{}};cache[id]=module;modules[id](function(spec){var target=maps[id][spec];if(!target)throw new Error(\'Unresolved bundled module: \'+spec);return load(target);},module,module.exports);return module.exports;}return load('+json.dumps(entry)+');});\n')
out=ROOT/'stage-batch.umd.js';out.write_text(''.join(parts))
print(hashlib.sha256(out.read_bytes()).hexdigest())
