//__scripting_lazy_cjs__
'use strict';
/** @type {import('./ref')} */
module.exports = ReferenceError;
