//__scripting_lazy_cjs__
'use strict';
/** @type {import('./min')} */
module.exports = Math.min;
