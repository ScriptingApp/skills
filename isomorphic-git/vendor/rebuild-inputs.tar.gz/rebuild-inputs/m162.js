//__scripting_lazy_cjs__
'use strict';
/** @type {import('./isNaN')} */
module.exports = Number.isNaN || function isNaN(a) {
    return a !== a;
};
