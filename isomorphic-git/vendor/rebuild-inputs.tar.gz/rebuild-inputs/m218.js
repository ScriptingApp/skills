//__scripting_lazy_cjs__
'use strict';
var hasSymbols = require('has-symbols/shams');
/** @type {import('.')} */
module.exports = function hasToStringTagShams() {
    return hasSymbols() && !!Symbol.toStringTag;
};
