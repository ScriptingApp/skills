//__scripting_lazy_cjs__
'use strict';
/** @type {import('.')} */
module.exports = Object;
