//__scripting_lazy_cjs__
'use strict';
/** @type {import('./eval')} */
module.exports = EvalError;
