//__scripting_lazy_cjs__
'use strict';
/** @type {import('./max')} */
module.exports = Math.max;
