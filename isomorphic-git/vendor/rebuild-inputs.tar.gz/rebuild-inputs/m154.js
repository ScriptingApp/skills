//__scripting_lazy_cjs__
'use strict';
/** @type {import('./uri')} */
module.exports = URIError;
