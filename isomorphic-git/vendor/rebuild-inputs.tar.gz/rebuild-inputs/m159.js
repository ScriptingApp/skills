//__scripting_lazy_cjs__
'use strict';
/** @type {import('./pow')} */
module.exports = Math.pow;
