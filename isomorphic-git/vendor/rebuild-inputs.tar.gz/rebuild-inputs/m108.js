//__scripting_lazy_cjs__
'use strict';
/** @type {import('./functionCall')} */
module.exports = Function.prototype.call;
