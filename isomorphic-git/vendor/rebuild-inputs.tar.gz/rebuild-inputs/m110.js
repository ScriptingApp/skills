//__scripting_lazy_cjs__
'use strict';
/** @type {import('./functionApply')} */
module.exports = Function.prototype.apply;
