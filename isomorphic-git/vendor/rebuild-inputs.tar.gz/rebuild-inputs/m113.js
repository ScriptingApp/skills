//__scripting_lazy_cjs__
'use strict';
/** @type {import('./gOPD')} */
module.exports = Object.getOwnPropertyDescriptor;
