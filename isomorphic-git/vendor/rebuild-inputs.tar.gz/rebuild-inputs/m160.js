//__scripting_lazy_cjs__
'use strict';
/** @type {import('./round')} */
module.exports = Math.round;
