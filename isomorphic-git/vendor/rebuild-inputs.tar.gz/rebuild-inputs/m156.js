//__scripting_lazy_cjs__
'use strict';
/** @type {import('./floor')} */
module.exports = Math.floor;
