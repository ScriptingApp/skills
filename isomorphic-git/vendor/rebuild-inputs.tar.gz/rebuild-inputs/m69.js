//__scripting_lazy_cjs__
'use strict';
var whichTypedArray = require('which-typed-array');
/** @type {import('.')} */
module.exports = function isTypedArray(value) {
    return !!whichTypedArray(value);
};
