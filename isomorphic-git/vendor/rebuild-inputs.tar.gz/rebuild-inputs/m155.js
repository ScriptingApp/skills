//__scripting_lazy_cjs__
'use strict';
/** @type {import('./abs')} */
module.exports = Math.abs;
