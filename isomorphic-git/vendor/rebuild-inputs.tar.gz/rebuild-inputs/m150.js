//__scripting_lazy_cjs__
'use strict';
/** @type {import('./range')} */
module.exports = RangeError;
