//__scripting_lazy_cjs__
'use strict';
/** @type {import('.')} */
var $gOPD = require('./gOPD');
if ($gOPD) {
    try {
        $gOPD([], 'length');
    }
    catch (e) {
        // IE 8 has a broken gOPD
        $gOPD = null;
    }
}
module.exports = $gOPD;
