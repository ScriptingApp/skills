//__scripting_lazy_cjs__
'use strict';
/** @type {import('./syntax')} */
module.exports = SyntaxError;
