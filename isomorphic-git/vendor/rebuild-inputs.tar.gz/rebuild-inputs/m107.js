//__scripting_lazy_cjs__
'use strict';
/** @type {import('./type')} */
module.exports = TypeError;
